class CreateCabin {
    constructor(obj) {
        this.cabinNumber = obj.cabinNumber;
        this.cabinWing = obj.cabinWing;
        this.cabinFloor = obj.cabinFloor;
        this.allocationStatus = obj.allocationStatus;
        this.allocatedUser = obj.allocatedUser;
    }
}

module.exports = CreateCabin;