// Inserting into cabin db
class InsertIntoCabin {
    constructor(obj1,obj2) {
        this.cabinNumber = obj2;
        let a = obj2.split("-");
        this.cabinWing =a[1] ;
        this.cabinFloor =a[0];
        this.allocationStatus = "Filled";
        this.allocatedUser = obj1;
    }
}

module.exports = InsertIntoCabin;

