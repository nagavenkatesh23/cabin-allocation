class CabinAllocation {
    constructor(obj) {
        this.empId = obj.empId;
        this.empName = obj.empName;
        this.userName = obj.userName;
        this.password = obj.password;
        this.designation = obj.designation;
        this.cabinNumber = obj.cabinNumber;
        this.stream = obj.stream;
    }
}

module.exports = CabinAllocation;