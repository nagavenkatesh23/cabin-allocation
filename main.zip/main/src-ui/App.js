import React,{Component} from '../node_modules/react';
import './App.css';
import User from './component/user';
import Login from './component/login'
import CabinDetails from './component/allcabindetails'
import { BrowserRouter as Router, Route, Switch, Link } from "react-router-dom";


// import Evaluator from './testing/evaluator';


class App extends Component {
  render() {
    return (
      <Router>
        <div>
          <Switch>
            <Route exact path="/user" component={User} />
            <Route exact path="/login" component={Login} />
            <Route exact path="/cabinDetails" component={CabinDetails} />
          </Switch>
        </div>
      </Router>
    );
  }
}

export default App;
