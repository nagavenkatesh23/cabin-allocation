import React, { Component } from "react";
import axios from "axios";
import "../App.css";
const url = "http://localhost:1050/login";

class Login extends Component {
    constructor(props) {
        super(props);
        this.state = {
            form: {
                userName: "",
                password: ""
            },
            formErrorMessage: {
                userName: "",
                password: ""
            },
            formValid: {
                userName: false,
                password: false,
                buttonActive: false
            },
            errorMessage: "",
        };
    }
    // loginCandidate = event => {
    //     event.preventDefault();//Prevent page from refreshing after submit
    //     //console.log(this.state.form)
    //     let url1 = url + this.state.form.userName + '/' + this.state.form.password + '/'
    //     console.log(url1)
    //     axios.get(url1)
    //         .then(res => {
    //             let examData = res.data
    //             examData.examDate = this.DaysToGo(res.data.examDate)
    //             //console.log(res.data, "success" )
    //             this.setState({ examData: examData }, () => { console.log(this.state.examData) })
    //         })
    //         .catch(err => {

    //             let errMsg = err.response ? err.response.data.message : "Server Error";
    //             this.setState({ errorMessage: errMsg })
    //         }
    //         )

    // };


    loginEmployee = event => {
        event.preventDefault();//Prevent page from refreshing after submit
        //console.log(this.state.form)
        // let url1 = url + this.state.form.userName + '/' + this.state.form.password + '/'
        console.log(url)
        console.log(this.state.form)
        axios.post(url,this.state.form)
        .then(response => {
          console.log(response)
          this.setState({ successMessage: response, errorMessage: "" });
        }).catch(error => {
          this.setState({ errorMessage: error.response.data.message, successMessage: "" });
        });

    };


    handleChange = event => {
        const target = event.target;
        const value = target.value;
        const name = target.name;
        //console.log(name,value)
        const { form } = this.state;
        this.setState({ form: { ...form, [name]: value } });
        this.validateField(name, value);
    };

    validateField = (fieldName, value) => {
        let message = "";
        let validity = false;
        let name = fieldName;
        switch (name) {
            case "userName":
                let regex = new RegExp(/^[A-z0-9]{6,}\.(trn|TRN)$/);
                value === "" ? message = "field required" : regex.test(value) ? message = "" : message = "username should be of 6 characters minimum and should end with .trn"
                break
            case "password":
                let regex1 = new RegExp(/^[A-z0-9\*\$\#\@\!\&\^\%\s]{5,}$/);
                value === "" ? message = "field required" : regex1.test(value) ? message = "" : message = "password invalid!password must be of length 5"
                break
            default:
                break
        }
        let formErrorMessagesObj = this.state.formErrorMessage;
        formErrorMessagesObj[name] = message;
        this.setState({ formErrorMessage: formErrorMessagesObj });
        // if(message !== ''){
        //     validity = false; //Message is not empty and field is not valid
        // }else{
        //     validity = true
        // }
        validity = message == "" ? true : false;
        let formValidityObj = this.state.formValid;
        formValidityObj[name] = validity;
        formValidityObj.buttonActive = (formValidityObj.userName && formValidityObj.password);
        this.setState({ formValid: formValidityObj })
    };

    render() {
        return (
            <div className="Login">
                <div className="row">
                    <div className="col-md-4 offset-md-1">
                        <br />
                        <div className="card">
                            <div className="card-header bg-custom"><h3>Login</h3></div>
                            <div className="card-body">
                                

                                <form onSubmit={this.loginEmployee}>
                                    {/* <h1>Login</h1> */}
                                    <div className="form-group">
                                        <label htmlFor="userName">userName</label>
                                        <input type="text" name="userName" id="userName" className="form-control" placeholder="userName" value={this.state.form.userName} onChange={this.handleChange} />
                                        <span name="userNameError" className="text-danger">
                                            {this.state.formErrorMessage.userName}
                                        </span>
                                    </div>
                                    <div className="form-group">
                                        <label htmlFor="password">Password</label>
                                        <input type="password" name="password" id="password" className="form-control" placeholder="password" value={this.state.form.password} onChange={this.handleChange} />
                                        <span name="passwordError" className="text-danger">
                                            {this.state.formErrorMessage.password}
                                        </span>
                                    </div>

                                    <button name="login" type="submit" className="btn btn-info btn-block" disabled={!this.state.formValid.buttonActive}>Login</button>
                                </form>


                                <span name="successMessage" className="text-success text-bold">
                                    {this.state.successMessage}
                                </span>
                                <span name="errorMessage" className="text-danger text-bold">
                                    {this.state.errorMessage}
                                </span>
                                <br/>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        );
    }
}

export default Login;