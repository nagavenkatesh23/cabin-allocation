import React, { Component } from "react";
import axios from "axios";
import "../App.css";
import 'bootstrap/dist/css/bootstrap.min.css';
// import SearchField from "react-search-field";
// import rojectimg from './component/projectimg.jpg'
const url = "http://localhost:3000/cabinDetails"

export default class User extends Component {
    constructor(props) {
        super(props);
        this.state = {
            availableCabin: [],
            
            formValid: {
                empId: "",
                buttonActive: true
            },
            errorMessage: "",
            successMessage: ""
        }
    }

    handleSubmit = event => {
        event.preventDefault();
        this.getAllCabinDetails();
    }

    getAllCabinDetails = () => {
        // let empId = this.state.form.empId
        let url = `http://localhost:1050/cabinDetails`
        //    console.log("in axios"+empId)
        axios.get(url)
            .then(res => {
                console.log( res.data)
                this.setState({ availableCabin: res.data })
                this.setState({ errorMessage: "" });
            })
            .catch(err => {
                let errMsg = err.response ? err.response.data.message : "Server Error"
                console.log(errMsg)
                this.setState({ errorMessage: errMsg })
                this.setState({ successMessage: "" });
            })
    }
    // handleChange = (event) => {
    //     console.log(event.target.name)
    //     console.log(event.target.value)
    //     const name = event.target.name;
    //     const value = event.target.value;
    //     this.setState({ form: { ...this.state.form, [name]: value } });
    //     this.validateField(name, value);
    // };
    // validateField = (fieldName, value) => {
    //     let message = "";
    //     let validity = false;
    //     switch (fieldName) {
    //         case "empId":
    //             let regex = new RegExp(/^[1-9][0-9]{5}$/);
    //             value === "" ? message = "Field required" : regex.test(value) ? message = "" : message = "employee id should not start with 0 and should be 6 digits"
    //             break;
    //         default:
    //             break;
    //     }
    //     let formErrorMessageObj = this.state.formErrorMessage;
    //     formErrorMessageObj[fieldName] = message
    //     console.log(formErrorMessageObj)
    //     this.setState({ formErrorMessage: formErrorMessageObj })
    //     validity = message ? false : true
    //     let formValidObj = this.state.formValid
    //     formValidObj[fieldName] = validity
    //     formValidObj.buttonActive = formValidObj.empId
    //     this.setState({ formValid: formValidObj })
    //     // console.log("aaaaaaaa"+this.state.form.empId)
    // }
     render() {
        return (
            <React.Fragment>
                <div className="container-fluid">
                    <div className="row mt-4">
                        <div className="col-lg-7  offset-lg-5">
                            {/* <div className="card bg-card text-light ">
                    <div className="card-body"> */}
                    {/* <div style={{backgroundImage:url({Projectimg})`}}></div> */}
                        <form onSubmit={this.handleSubmit}>
                        <button type="submit" className="btn btn-primary " >View Cabin Details</button>
                        </form>
                    </div>
                    <span name="successMessage" className="text-danger">{this.state.successMessage}</span>
                    <span name="errorMessage" className="text-danger">{this.state.errorMessage}</span>
                    {/* </div> */}
                    {/* </div> */}
                </div>
                    {
                        this.state.availableCabin != "" ? (
                            <div className="mt-3">
                                {/* Display the booking details here by rendering the BookingDetailsCard component and passing bookingData as props*/}
                               {/* {this.state.availableCabin.map((d)=>{console.log(d.cabinFloor); */}
                               {/* }) */}
                               <div className="text-center"><b><i>CABIN DETAILS</i></b></div> 
                               <br/>
                                {
                                    //  <div className="text-center">EMPLOYEE DETAILS</div> 
                                    <table className="table table-dark table-bordered">
                                        <thead>
                                                {/* <div className="text-center">EMPLOYEE DETAILS</div> */}
                                            <tr>
                                                {/* <th>Employee Id</th>
                                                <th>Employee Name</th>
                                                <th>User Name</th>
                                                <th>Designation</th>
                                                <th>Stream</th> */}
                                                <th>Cabin Number</th>
                                                <th>Cabin Wing</th>
                                                <th>Cabin Floor</th>
                                                <th>Allocation Status</th>
                                                <th>Allocated User</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        {this.state.availableCabin.map((data, i) => {
                              console.log(data);
                              
                             return(
                              <tr key={i}>
                                                {/* <td>{this.state.availableCabin[0].empId}</td>
                                                <td>{this.state.availableCabin[0].empName}</td>
                                                <td>{this.state.availableCabin[0].userName}</td>
                                                <td>{this.state.availableCabin[0].designation}</td>
                                                <td>{this.state.availableCabin[0].stream}</td> */}
                                                <td>{this.state.availableCabin[i].cabinNumber}</td>
                                                <td>{this.state.availableCabin[i].cabinWing}</td>
                                                <td>{this.state.availableCabin[i].cabinFloor}</td>
                                                <td>{this.state.availableCabin[ i].allocationStatus}</td>
                                                <td>{this.state.availableCabin[i].allocatedUser}</td>
                                            </tr>
                                        )

                                        })
                                        
                                        }



                                        </tbody>
                                    </table>
                                }
                            </div>
                        ) : null
                    }
                </div>
                {/* {console.log(this.state)} */}
               
                
            </React.Fragment>
        )
    }
}
